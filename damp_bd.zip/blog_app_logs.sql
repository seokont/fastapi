-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_logs`
--

DROP TABLE IF EXISTS `app_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `level` varchar(255) NOT NULL,
  `message` varchar(9000) NOT NULL,
  `meta` text NOT NULL,
  `timestamp` datetime NOT NULL,
  KEY `index_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_logs`
--

LOCK TABLES `app_logs` WRITE;
/*!40000 ALTER TABLE `app_logs` DISABLE KEYS */;
INSERT INTO `app_logs` VALUES (1,'error','author.save is not a function','{\"stack\":\"TypeError: author.save is not a function\\n    at E:\\\\PROJECT\\\\FastApi\\\\dist\\\\routes\\\\authors\\\\authors.js:43:18\\n    at Generator.next (<anonymous>)\\n    at fulfilled (E:\\\\PROJECT\\\\FastApi\\\\dist\\\\routes\\\\authors\\\\authors.js:5:58)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\",\"request\":{\"headers\":{\"content-type\":\"application/json\",\"user-agent\":\"PostmanRuntime/7.39.0\",\"accept\":\"*/*\",\"postman-token\":\"ccb23adf-7529-4b07-95a3-bafa5cd71c62\",\"host\":\"localhost:3000\",\"accept-encoding\":\"gzip, deflate, br\",\"connection\":\"keep-alive\",\"content-length\":\"23\"},\"query\":{},\"originalUrl\":\"/authors/647c1441-2726-428b-ba9e-5f91be7b288d\",\"body\":{\"name\":\"Фртур2\"},\"method\":\"PUT\",\"path\":\"/647c1441-2726-428b-ba9e-5f91be7b288d\",\"baseUrl\":\"/authors\",\"protocol\":\"http\"}}','2024-06-26 16:47:49'),(2,'error','Categories is associated to Posts using an alias. You\'ve included an alias (created_by_author), but it does not match the alias(es) defined in your association (created_category).','{\"stack\":\"SequelizeEagerLoadingError: Categories is associated to Posts using an alias. You\'ve included an alias (created_by_author), but it does not match the alias(es) defined in your association (created_category).\\n    at Posts._getIncludedAssociation (E:\\\\PROJECT\\\\FastApi\\\\node_modules\\\\sequelize\\\\lib\\\\model.js:574:15)\\n    at Posts._validateIncludedElement (E:\\\\PROJECT\\\\FastApi\\\\node_modules\\\\sequelize\\\\lib\\\\model.js:502:53)\\n    at E:\\\\PROJECT\\\\FastApi\\\\node_modules\\\\sequelize\\\\lib\\\\model.js:421:37\\n    at Array.map (<anonymous>)\\n    at Posts._validateIncludedElements (E:\\\\PROJECT\\\\FastApi\\\\node_modules\\\\sequelize\\\\lib\\\\model.js:417:39)\\n    at Posts.findAll (E:\\\\PROJECT\\\\FastApi\\\\node_modules\\\\sequelize\\\\lib\\\\model.js:1124:12)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\",\"request\":{\"headers\":{\"content-type\":\"application/json\",\"user-agent\":\"PostmanRuntime/7.39.0\",\"accept\":\"*/*\",\"postman-token\":\"53dc773c-eaae-4f8b-9cfc-4dcd933c43d0\",\"host\":\"localhost:3000\",\"accept-encoding\":\"gzip, deflate, br\",\"connection\":\"keep-alive\",\"content-length\":\"204\"},\"query\":{},\"originalUrl\":\"/post\",\"body\":{\"title\":\"gfgfg333333333\",\"text\":\"ggfg fg fghhggh jhjhh hj\",\"categoriesId\":\"9262674c-08ed-49e0-9676-b341b4e03570\",\"authorId\":\"897db3e2-c76c-4cc2-aa62-587a1c043652\"},\"method\":\"GET\",\"path\":\"/\",\"baseUrl\":\"/post\",\"protocol\":\"http\"}}','2024-06-26 17:18:08');
/*!40000 ALTER TABLE `app_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 22:53:37
